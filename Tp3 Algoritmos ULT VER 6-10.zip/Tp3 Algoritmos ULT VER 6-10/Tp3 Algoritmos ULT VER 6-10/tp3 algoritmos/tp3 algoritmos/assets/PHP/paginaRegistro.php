<?php
header("Content-Type: application/json; charset=UTF-8");
require_once "conexion.php";

$datosRaw = file_get_contents("php://input");
$datos = json_decode($datosRaw, true);

if (!$datos || empty($datos['correo']) || empty($datos['password'])) {
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos requeridos."]);
    exit();
}

$correo   = trim($datos['correo']);
$password = $datos['password'];
$metodo   = 'manual';

try {
    $stmtCheck = $conexion->prepare("SELECT id_usuario FROM usuarios WHERE correo_electronico = :correo");
    $stmtCheck->bindParam(':correo', $correo);
    $stmtCheck->execute();

    if ($stmtCheck->rowCount() > 0) {
        echo json_encode(["exito" => false, "mensaje" => "El correo electrónico ya se encuentra registrado."]);
        exit();
    }

    $passwordHash = password_hash($password, PASSWORD_BCRYPT);

    $sql = "INSERT INTO usuarios (correo_electronico, contrasena, metodo_registro) VALUES (:correo, :pass, :metodo)";
    $stmtInsert = $conexion->prepare($sql);
    $stmtInsert->bindParam(':correo', $correo);
    $stmtInsert->bindParam(':pass', $passwordHash);
    $stmtInsert->bindParam(':metodo', $metodo);

    if ($stmtInsert->execute()) {
        $idNuevoUsuario = $conexion->lastInsertId();
        echo json_encode([
            "exito" => true,
            "mensaje" => "Registro exitoso.",
            "id_usuario" => $idNuevoUsuario
        ]);
    } else {
        echo json_encode(["exito" => false, "mensaje" => "No se pudo registrar el usuario."]);
    }
} catch (PDOException $e) {
    echo json_encode(["exito" => false, "mensaje" => "Error de servidor: " . $e->getMessage()]);
}
?>