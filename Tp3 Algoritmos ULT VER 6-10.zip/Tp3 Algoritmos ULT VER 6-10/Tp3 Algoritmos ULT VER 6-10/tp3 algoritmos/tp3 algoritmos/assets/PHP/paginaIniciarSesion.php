<?php
header("Content-Type: application/json; charset=UTF-8");
require_once "conexion.php";

$datosRaw = file_get_contents("php://input");
$datos = json_decode($datosRaw, true);

if (!$datos || empty($datos['proveedor'])) {
    echo json_encode(["exito" => false, "mensaje" => "Proveedor no especificado."]);
    exit();
}

$proveedor = strtolower(trim($datos['proveedor']));
$correo    = "usuario_" . $proveedor . "@veinzer.com";

try {
    $stmtCheck = $conexion->prepare("SELECT id_usuario FROM usuarios WHERE correo_electronico = :correo");
    $stmtCheck->bindParam(':correo', $correo);
    $stmtCheck->execute();

    if ($usuarioExistente = $stmtCheck->fetch()) {
        $idUsuario = $usuarioExistente['id_usuario'];
    } else {
        $stmtInsert = $conexion->prepare("INSERT INTO usuarios (correo_electronico, contrasena, metodo_registro) VALUES (:correo, NULL, :metodo)");
        $stmtInsert->bindParam(':correo', $correo);
        $stmtInsert->bindParam(':metodo', $proveedor);
        $stmtInsert->execute();
        $idUsuario = $conexion->lastInsertId();
    }

    echo json_encode([
        "exito" => true,
        "mensaje" => "Sesión iniciada con " . ucfirst($proveedor),
        "id_usuario" => $idUsuario,
        "correo" => $correo
    ]);
} catch (PDOException $e) {
    echo json_encode(["exito" => false, "mensaje" => "Error de servidor: " . $e->getMessage()]);
}
?>