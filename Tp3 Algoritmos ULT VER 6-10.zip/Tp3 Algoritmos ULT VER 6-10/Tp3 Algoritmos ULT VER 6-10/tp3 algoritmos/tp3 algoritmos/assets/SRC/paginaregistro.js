document.addEventListener('DOMContentLoaded', function () {

    let formRegistro = document.getElementById('formRegistro');
    if (formRegistro) {
        formRegistro.addEventListener('submit', registrarUsuario);
    }

    let btnGoogle = document.getElementById('btnGogle');
    if (btnGoogle) {
        btnGoogle.addEventListener('click', function () {
            iniciarSesionSocial('Google');
        });
    }

    let btnFacebook = document.getElementById('btnFacebook');
    if (btnFacebook) {
        btnFacebook.addEventListener('click', function () {
            iniciarSesionSocial('Facebook');
        });
    }

    let btnApple = document.getElementById('btnApple');
    if (btnApple) {
        btnApple.addEventListener('click', function () {
            iniciarSesionSocial('Apple');
        });
    }
});

async function registrarUsuario(event) {
    event.preventDefault();

    let correo = document.getElementById('correoelectronico').value.trim();
    let pass1 = document.getElementById('password').value;
    let pass2 = document.getElementById('password2').value;

    if (correo === '' || pass1 === '' || pass2 === '') {
        alert('Por favor, ingresá todos los datos requeridos.');
        return;
    }

    if (pass1 !== pass2) {
        alert('Las contraseñas no coinciden. Por favor, verificá los datos.');
        return;
    }

    try {
        let respuesta = await fetch('assets/PHP/paginaRegistro.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                correo: correo,
                password: pass1
            })
        });

        let resultado = await respuesta.json();

        if (resultado.exito) {
            let usuario = {
                id_usuario: resultado.id_usuario,
                correo: correo,
                metodo: 'correo',
                sesionActiva: true
            };
            localStorage.setItem('usuarioRegistrado', JSON.stringify(usuario));

            alert("Registro Exitoso en la base de datos. Inicie sesión para continuar.");
            window.location.href = 'paginaIniciarSesion.html';
        } else {
            alert("Error al registrar: " + resultado.mensaje);
        }
    } catch (error) {
        console.error("Error en la petición:", error);
        alert("Ocurrió un error al conectar con el servidor.");
    }
}

async function iniciarSesionSocial(proveedor) {
    try {
        let respuesta = await fetch('assets/PHP/paginaIniciarSesion.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                proveedor: proveedor
            })
        });

        let resultado = await respuesta.json();

        if (resultado.exito) {
            let usuarioSesion = {
                id_usuario: resultado.id_usuario,
                correo: resultado.correo,
                metodo: proveedor,
                sesionActiva: true
            };

            localStorage.setItem('usuarioRegistrado', JSON.stringify(usuarioSesion));

            alert('Iniciando sesión con ' + proveedor + '...');
            window.location.href = 'paginaprincipal.html';
        } else {
            alert('Error al autenticar: ' + resultado.mensaje);
        }
    } catch (error) {
        console.error("Error en la sesión social:", error);
        alert("Ocurrió un error al conectar con el servidor.");
    }
}