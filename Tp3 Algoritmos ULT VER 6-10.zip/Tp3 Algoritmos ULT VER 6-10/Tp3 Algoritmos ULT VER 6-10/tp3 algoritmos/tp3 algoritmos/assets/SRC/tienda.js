
const PRODUCTOS = [
    { id: 1,  nombre: "Proteína Whey",     precio: 28500, imagen: "assets/IMG/" },
    { id: 2,  nombre: "Creatina",          precio: 19900, imagen: "assets/IMG/" },
    { id: 3,  nombre: "BCAA",              precio: 16400, imagen: "assets/IMG/" },
    { id: 4,  nombre: "Pre-entreno",       precio: 22300, imagen: "assets/IMG/" },
    { id: 5,  nombre: "Multivitamínico",   precio: 12800, imagen: "assets/IMG/" },
    { id: 6,  nombre: "Omega 3",           precio: 14200, imagen: "assets/IMG/" },
    { id: 7,  nombre: "Caseína",           precio: 31000, imagen: "assets/IMG/" },
    { id: 8,  nombre: "Glutamina",         precio: 17600, imagen: "assets/IMG/" },
    { id: 9,  nombre: "Barras proteicas",  precio: 9800,  imagen: "assets/IMG/" },
    { id: 10, nombre: "Quemador de grasa", precio: 20500, imagen: "assets/IMG/" }
];

const CLAVE_CARRITO = "veinzerCarrito";

const grilla = document.getElementById("grillaProductos");
const btnCarrito = document.getElementById("btnCarrito");
const panel = document.getElementById("panelCarrito");
const contador = document.getElementById("contadorCarrito");
const lista = document.getElementById("itemsCarrito");
const vacio = document.getElementById("carritoVacio");
const totalEl = document.getElementById("totalCarrito");
const btnComprar = document.getElementById("btnComprar");
const mensaje = document.getElementById("mensajeCompra");


let carrito = leerCarrito();

function leerCarrito() {
    try {
        const guardado = JSON.parse(localStorage.getItem(CLAVE_CARRITO));
        return guardado && typeof guardado === "object" ? guardado : {};
    } catch (e) {
        return {};
    }
}

function guardarCarrito() {
    try {
        localStorage.setItem(CLAVE_CARRITO, JSON.stringify(carrito));
    } catch (e) {  }
}

function formatoPrecio(n) {
    return "$" + n.toLocaleString("es-AR");
}

function buscar(id) {
    return PRODUCTOS.find(p => p.id === Number(id));
}

function dibujarProductos() {
    grilla.innerHTML = "";
    PRODUCTOS.forEach(p => {
        const art = document.createElement("article");
        art.className = "producto";
        art.innerHTML = `
            <div class="producto-imagen"><img src="${p.imagen}" alt="${p.nombre}"></div>
            <h3 class="producto-nombre">${p.nombre}</h3>
            <button type="button" class="btn-agregar" data-id="${p.id}">
                <span>Añadir al carrito</span>
                <strong>${formatoPrecio(p.precio)}</strong>
            </button>`;
        grilla.appendChild(art);
    });
}

grilla.addEventListener("click", e => {
    const btn = e.target.closest(".btn-agregar");
    if (!btn) return;
    cambiarCantidad(btn.dataset.id, 1);
    btn.classList.remove("agregado");
    void btn.offsetWidth; 
    btn.classList.add("agregado");
});


function cambiarCantidad(id, delta) {
    const nueva = (carrito[id] || 0) + delta;
    if (nueva <= 0) {
        delete carrito[id];
    } else {
        carrito[id] = nueva;
    }
    mensaje.textContent = "";
    guardarCarrito();
    dibujarCarrito();
}

function dibujarCarrito() {
    lista.innerHTML = "";
    let unidades = 0;
    let total = 0;

    Object.keys(carrito).forEach(id => {
        const p = buscar(id);
        if (!p) return;
        const cant = carrito[id];
        unidades += cant;
        total += p.precio * cant;

        const li = document.createElement("li");
        li.className = "item-carrito";
        li.innerHTML = `
            <div class="item-imagen"><img src="${p.imagen}" alt=""></div>
            <div class="item-datos">
                <p class="item-nombre">${p.nombre}</p>
                <p class="item-precio">Precio ${formatoPrecio(p.precio * cant)}</p>
                <div class="item-cantidad">
                    <span>Cant: ${cant}</span>
                    <button type="button" data-id="${id}" data-delta="1" aria-label="Sumar uno de ${p.nombre}">+</button>
                    <button type="button" data-id="${id}" data-delta="-1" aria-label="Restar uno de ${p.nombre}">−</button>
                </div>
            </div>`;
        lista.appendChild(li);
    });

    contador.textContent = unidades;
    contador.hidden = unidades === 0;
    vacio.hidden = unidades !== 0;
    totalEl.textContent = formatoPrecio(total);
    btnComprar.disabled = unidades === 0;
}

lista.addEventListener("click", e => {
    const btn = e.target.closest("button[data-id]");
    if (!btn) return;
    cambiarCantidad(btn.dataset.id, Number(btn.dataset.delta));
});

btnComprar.addEventListener("click", () => {
    carrito = {};
    guardarCarrito();
    dibujarCarrito();
    mensaje.textContent = "¡Compra realizada! Gracias por elegir Veinzer.";
});


function abrirPanel(abrir) {
    panel.hidden = !abrir;
    btnCarrito.setAttribute("aria-expanded", String(abrir));
    if (!abrir) mensaje.textContent = "";
}

btnCarrito.addEventListener("click", () => abrirPanel(panel.hidden));

document.addEventListener("click", e => {
    if (!panel.hidden && !e.target.closest(".carrito")) abrirPanel(false);
});

document.addEventListener("keydown", e => {
    if (e.key === "Escape" && !panel.hidden) {
        abrirPanel(false);
        btnCarrito.focus();
    }
});

dibujarProductos();
dibujarCarrito();