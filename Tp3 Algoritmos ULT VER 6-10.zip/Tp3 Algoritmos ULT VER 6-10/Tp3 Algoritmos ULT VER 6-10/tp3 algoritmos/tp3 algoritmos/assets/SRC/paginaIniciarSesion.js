document.addEventListener('DOMContentLoaded', function () {

    let formLogin = document.getElementById('formLogin')
    if (formLogin) {
        formLogin.addEventListener('submit', iniciarSesion)
    }

    let btnGoogle = document.getElementById('btnGogle')
    if (btnGoogle) {
        btnGoogle.addEventListener('click', function () {
            iniciarSesionConProveedor('Google')
        })
    }

    let btnFacebook = document.getElementById('btnFacebook')
    if (btnFacebook) {
        btnFacebook.addEventListener('click', function () {
            iniciarSesionConProveedor('Facebook')
        })
    }

    let btnApple = document.getElementById('btnApple')
    if (btnApple) {
        btnApple.addEventListener('click', function () {
            iniciarSesionConProveedor('Apple')
        })
    }
})

function iniciarSesion(event) {
    event.preventDefault()

    let correo = document.getElementById('correoelectronico').value.trim()
    let pass = document.getElementById('password').value

    if (correo === '' || pass === '') {
        alert('Por favor, ingresá tu correo electrónico y contraseña.')
        return
    }

    let usuarioGuardado = JSON.parse(localStorage.getItem('usuarioRegistrado'))

    if (usuarioGuardado && usuarioGuardado.correo === correo && usuarioGuardado.password === pass) {
        usuarioGuardado.sesionActiva = true
        localStorage.setItem('usuarioRegistrado', JSON.stringify(usuarioGuardado))

        alert('¡Inicio de sesión exitoso!')
        window.location.href = 'paginaprincipal.html'
    } else {
        alert('El correo o la contraseña son incorrectos.')
    }
}

function iniciarSesionConProveedor(proveedor) {
    let usuarioSesion = {
        correo: 'usuario_' + proveedor.toLowerCase() + '@veinzer.com',
        metodo: proveedor,
        sesionActiva: true
    }

    localStorage.setItem('usuarioRegistrado', JSON.stringify(usuarioSesion))

    alert('Iniciando sesión con ' + proveedor + '...')
    window.location.href = 'paginaprincipal.html'
}