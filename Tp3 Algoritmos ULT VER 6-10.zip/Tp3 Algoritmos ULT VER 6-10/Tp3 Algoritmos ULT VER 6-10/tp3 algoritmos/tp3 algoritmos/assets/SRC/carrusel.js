document.addEventListener('DOMContentLoaded', () => {
    const track = document.getElementById('carruselTrack');
    const slides = document.querySelectorAll('.carrusel-slide');
    const indicadores = document.querySelectorAll('#carruselIndicadores span');

    if (!track || slides.length === 0 || indicadores.length === 0) return;

    let indiceActual = 0;
    const totalSlides = slides.length;
    let intervalo = null;

    function moverCarrusel(index) {
        if (index < 0 || index >= totalSlides) return;

        // 1. Quitar clase 'activo' de la imagen e indicador anteriores
        slides[indiceActual].classList.remove('activo');
        indicadores[indiceActual].classList.remove('activo');

        // 2. Actualizar el índice actual
        indiceActual = index;

        // 3. Añadir clase 'activo' a la nueva foto e indicador
        slides[indiceActual].classList.add('activo');
        indicadores[indiceActual].classList.add('activo');

        // 4. Mover la tira para centrar la tarjeta activa
        track.style.transform = `translateX(-${indiceActual * 100}%)`;
    }

    function siguienteSlide() {
        let nuevoIndice = (indiceActual + 1) % totalSlides;
        moverCarrusel(nuevoIndice);
    }

    function iniciarAutoplay() {
        detenerAutoplay();
        intervalo = setInterval(siguienteSlide, 4000); // Cambia cada 4 segundos
    }

    function detenerAutoplay() {
        if (intervalo) clearInterval(intervalo);
    }

    // Eventos para hacer clic en los indicadores
    indicadores.forEach((btn, idx) => {
        btn.addEventListener('click', () => {
            moverCarrusel(idx);
            iniciarAutoplay(); // Reinicia el tiempo cuando el usuario hace clic
        });
    });

    // Iniciar temporizador automático
    iniciarAutoplay();
});