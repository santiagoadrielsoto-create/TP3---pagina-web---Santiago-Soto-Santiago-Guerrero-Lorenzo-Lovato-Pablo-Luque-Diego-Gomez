

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";



CREATE TABLE `consultas` (
  `id_consulta` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `ultimo_imc` decimal(5,2) NOT NULL,
  `estado_imc` varchar(50) NOT NULL,
  `peso_actual_kg` decimal(5,2) NOT NULL,
  `calorias_diarias_kcal` decimal(7,2) DEFAULT NULL,
  `total_consultas_realizadas` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `fecha_ultima_consulta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `datos_usuario` (
  `id_datos` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `peso_kg` decimal(5,2) NOT NULL,
  `altura_cm` decimal(5,2) NOT NULL,
  `edad` int(10) UNSIGNED NOT NULL,
  `nivel_actividad` enum('sedentario','ligero','moderado','intenso','muy_intenso') NOT NULL,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `detalle_pedido` (
  `id_detalle` int(10) UNSIGNED NOT NULL,
  `id_pedido` int(10) UNSIGNED NOT NULL,
  `id_producto` int(10) UNSIGNED NOT NULL,
  `cantidad` int(10) UNSIGNED NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) GENERATED ALWAYS AS (`cantidad` * `precio_unitario`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `historial_mediciones` (
  `id_historial` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `fecha_registro` date NOT NULL,
  `peso_kg` decimal(5,2) NOT NULL,
  `altura_cm` decimal(5,2) NOT NULL,
  `imc` decimal(5,2) NOT NULL,
  `estado_imc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `mediciones_metricas` (
  `id_medicion` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `peso_kg` decimal(5,2) NOT NULL,
  `altura_cm` decimal(5,2) NOT NULL,
  `edad` int(10) UNSIGNED NOT NULL,
  `imc` decimal(5,2) NOT NULL,
  `categoria_imc` varchar(50) NOT NULL,
  `tdee_calorias` decimal(7,2) DEFAULT NULL,
  `objetivo_recomendado` varchar(100) DEFAULT NULL,
  `rutina_ideal` varchar(200) DEFAULT NULL,
  `fecha_calculo` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `pedidos` (
  `id_pedido` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `estado` enum('pendiente','pagado','enviado','entregado','cancelado') NOT NULL DEFAULT 'pendiente',
  `fecha_compra` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `productos` (
  `id_producto` int(10) UNSIGNED NOT NULL,
  `nombre_producto` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `imagen_url` varchar(500) DEFAULT NULL,
  `stock` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `recomendaciones` (
  `id_recomendacion` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `rango_imc` varchar(50) NOT NULL,
  `tipo_recomendacion` enum('alimentacion','ejercicio','habito') NOT NULL,
  `descripcion_recomendacion` text NOT NULL,
  `fecha_generada` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `usuarios` (
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `correo_electronico` varchar(150) NOT NULL,
  `contrasena` varchar(255) DEFAULT NULL,
  `metodo_registro` enum('manual','google','facebook','apple') NOT NULL DEFAULT 'manual',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


ALTER TABLE `consultas`
  ADD PRIMARY KEY (`id_consulta`),
  ADD UNIQUE KEY `id_usuario` (`id_usuario`);

ALTER TABLE `datos_usuario`
  ADD PRIMARY KEY (`id_datos`),
  ADD UNIQUE KEY `id_usuario` (`id_usuario`);


ALTER TABLE `detalle_pedido`
  ADD PRIMARY KEY (`id_detalle`),
  ADD UNIQUE KEY `uq_producto_pedido` (`id_pedido`,`id_producto`),
  ADD KEY `idx_detalle_producto` (`id_producto`);

ALTER TABLE `historial_mediciones`
  ADD PRIMARY KEY (`id_historial`),
  ADD KEY `idx_historial_usuario_fecha` (`id_usuario`,`fecha_registro`);

ALTER TABLE `mediciones_metricas`
  ADD PRIMARY KEY (`id_medicion`),
  ADD KEY `idx_mediciones_usuario` (`id_usuario`);

ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `idx_pedidos_usuario_fecha` (`id_usuario`,`fecha_compra`);

ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`);

ALTER TABLE `recomendaciones`
  ADD PRIMARY KEY (`id_recomendacion`),
  ADD KEY `idx_recomendaciones_usuario` (`id_usuario`);

ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `correo_electronico` (`correo_electronico`);

ALTER TABLE `consultas`
  MODIFY `id_consulta` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `datos_usuario`
  MODIFY `id_datos` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `detalle_pedido`
  MODIFY `id_detalle` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;


ALTER TABLE `historial_mediciones`
  MODIFY `id_historial` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `mediciones_metricas`
  MODIFY `id_medicion` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;


ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `productos`
  MODIFY `id_producto` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `recomendaciones`
  MODIFY `id_recomendacion` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;


ALTER TABLE `consultas`
  ADD CONSTRAINT `fk_consultas_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `datos_usuario`
  ADD CONSTRAINT `fk_datos_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `detalle_pedido`
  ADD CONSTRAINT `fk_detalle_pedido` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_detalle_producto` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`) ON UPDATE CASCADE;


ALTER TABLE `historial_mediciones`
  ADD CONSTRAINT `fk_historial_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `mediciones_metricas`
  ADD CONSTRAINT `fk_mediciones_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE;


ALTER TABLE `pedidos`
  ADD CONSTRAINT `fk_pedidos_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE;


ALTER TABLE `recomendaciones`
  ADD CONSTRAINT `fk_recomendaciones_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

